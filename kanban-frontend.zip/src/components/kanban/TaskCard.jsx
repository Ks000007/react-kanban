import { useDraggable } from "@dnd-kit/core";
import { TaskStatus } from '../../types/types';

export function TaskCard({ task, onOpenDetails, users }) {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: task.id,
  });

  const style = transform
    ? {
        transform: `translate(${transform.x}px, ${transform.y}px)`,
      }
    : undefined;

  const handleDetailsClick = (e) => {
    e.stopPropagation();
    onOpenDetails(task);
  };
  
  const getProgressColorClass = (progress, status) => {
    if (status === TaskStatus.TODO) return 'bg-gray-500';
    if (status === TaskStatus.DONE) return 'bg-green-500';
    return 'bg-yellow-500';
  };

  // Ensure task.assignedTo is an array before calling .includes()
  const assignedUsers = users.filter(user => (task.assignedTo || []).includes(user.id));

  // Helper function for overdue styling
  const isOverdue = (date) => {
    if (!date) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dueDate = new Date(date);
    return dueDate < today && task.status !== TaskStatus.DONE;
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="rounded-lg bg-neutral-700 p-4 shadow-sm hover:shadow-md transition-shadow relative flex flex-col"
    >
      {/* Drag Handle */}
      <div
        {...listeners}
        {...attributes}
        className="cursor-grab pb-2 mb-2 border-b border-neutral-600 flex-grow"
      >
        <h3 className="font-medium text-neutral-100">{task.title}</h3>
        <p className="mt-2 text-sm text-neutral-400">{task.description}</p>
        
        {/* Display Dates */}
        <div className="mt-2 text-xs flex flex-wrap items-center gap-2">
          {task.dueDate && (
            <div className={`flex items-center space-x-1 ${isOverdue(task.dueDate) ? 'text-red-400' : 'text-neutral-400'}`}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
              </svg>
              <span>{task.dueDate}</span>
            </div>
          )}
          {task.startDate && (
            <div className="flex items-center space-x-1 text-neutral-400">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path d="M4 4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1.586a1 1 0 01-.707-.293l-1.414-1.414A1 1 0 0010.586 2h-1.172a1 1 0 00-.707.293L7.293 3.586A1 1 0 016.586 4H5a2 2 0 00-2 2zM3 7v9a1 1 0 001 1h12a1 1 0 001-1V7H3z" />
              </svg>
              <span>{task.startDate}</span>
            </div>
          )}
        </div>
      </div>

      {/* Footer with Progress Bar and Details Button */}
      <div className="flex justify-between items-center mt-2">
        {/* Progress Bar with dynamic styling */}
        <div className="w-full bg-neutral-600 rounded-full h-2.5 mr-4 overflow-hidden shadow-inner">
          <div
            className={`h-full rounded-full transition-all duration-500 ease-in-out ${getProgressColorClass(task.progress, task.status)}`}
            style={{ width: `${task.progress || 0}%` }}
          ></div>
        </div>
        
        {/* User Avatars and Details Button container */}
        <div className="flex-shrink-0 flex items-center space-x-2">
          {/* Display multiple avatars */}
          <div className="flex -space-x-2 overflow-hidden">
            {assignedUsers.slice(0, 3).map(assignedUser => (
              <img 
                key={assignedUser.id}
                src={assignedUser.avatar} 
                alt={assignedUser.name} 
                title={assignedUser.name}
                className="w-6 h-6 rounded-full border-2 border-neutral-500" 
              />
            ))}
            {assignedUsers.length > 3 && (
              <div className="w-6 h-6 rounded-full bg-neutral-600 flex items-center justify-center border-2 border-neutral-500 text-neutral-300 text-xs">
                +{assignedUsers.length - 3}
              </div>
            )}
          </div>
          {assignedUsers.length === 0 && (
            <div className="w-6 h-6 rounded-full bg-neutral-600 flex items-center justify-center border-2 border-dashed border-neutral-500 text-neutral-400">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
              </svg>
            </div>
          )}
          
          {/* Details Button */}
          <button
            onClick={handleDetailsClick}
            className="p-1 px-3 text-xs text-neutral-400 hover:text-neutral-100 bg-neutral-600 hover:bg-neutral-500 rounded transition-colors"
            title="View Details"
          >
            Details
          </button>
        </div>
      </div>
    </div>
  );
}