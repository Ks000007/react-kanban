import { RegisterForm } from "../components/auth/RegistrationForm";
export const RegisterPage = () => {
  return <RegisterForm />;
};
